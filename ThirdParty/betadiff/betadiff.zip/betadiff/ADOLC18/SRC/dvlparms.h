#ifndef _DVLPARMS_H_
#define _DVLPARMS_H_
/*
   -----------------------------------------------------------------
   File dvlparms.h of ADOL-C version 1.8.4           as of Aug/16/99
   -----------------------------------------------------------------
   The sole purpose of this file is to provide the developers and          
   maintainers of ADOL-C and include file that contains library wide       
   definitions, etc.                                                       

   Last changes:
     990816 olvo:  version 1.8.4
     990310 olvo:  version 1.8.2
     981130 olvo:  last check

   -----------------------------------------------------------------
*/


/****************************************************************************/
/* Define Compsize */
#define compsize >


/****************************************************************************/
/* Possible ADOL-C options. */
#define overwrite overwrite 


/****************************************************************************/
/* ADOLC - Version. */
#define ADOLC_VERSION     1
#define ADOLC_SUBVERSION  8
#define ADOLC_PATCHLEVEL  4


#endif








