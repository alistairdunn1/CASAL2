#define _ADOLC_SRC_

#include "dvlparms.h" /* Developers Parameters */
#include "usrparms.h" /* Users Parameters */
#include "interfaces.h"
//#include "oplate.h"
#include "adalloc.h"
#include "taputil.h"
#include "tayutil.h"

#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#define __null 0

static short tag;

static int for_location_cnt;
static int dep_cnt;
static int ind_cnt;


static int valstack;

int zos_forward(
   short tnum,
   int depcheck,
   int indcheck,

   int keep,

   double *basepoint,
   double *valuepoint)
// 443 "uni5_for.cpp"
{


  unsigned char operation;
  int tape_stats[13];
  int ret_c =3;

  unsigned int size = 0;
  unsigned int res = 0;
  unsigned int arg = 0;
  unsigned int arg1 = 0;
  unsigned int arg2 = 0;
  unsigned int checkSize;

  double coval = 0, *d = 0;

  int indexi = 0, indexd = 0;


  int i, j, l, ls;


  double r0, x, y, divs;
  int op_buffer, loc_buffer, real_buffer, even, flag;
  static int fax, kax, pax;


  static double *T0;
// 484 "uni5_for.cpp"
  double T0temp;
// 494 "uni5_for.cpp"
  int numoperations;



  int taylbuf;
// 527 "uni5_for.cpp"
  tag = tnum;

  tapestats(tag,tape_stats);
  ind_cnt = tape_stats[0];
  dep_cnt = tape_stats[1];
  for_location_cnt = tape_stats[2];
  op_buffer = tape_stats[4];
  loc_buffer = tape_stats[5];
  real_buffer = tape_stats[6];





  valstack = tape_stats[3];
  numoperations = tape_stats[7];




  set_buf_size(op_buffer,loc_buffer,real_buffer);

  if ((depcheck != dep_cnt)||(indcheck != ind_cnt))
  { fprintf((DIAG_OUT),"ADOL-C error: forward sweep on tape %d  aborted!\n",tag);
    fprintf((DIAG_OUT),"Number of dependent and/or independent variables passed"
                   " to forward is\ninconsistant with number"
                   " recorded on tape %d \n",tag);
    exit (-1);
  }
// 565 "uni5_for.cpp"
  if (keep>1){
    fprintf((DIAG_OUT),"\n ADOL-C error: zero order scalar forward cannot save"
                   " more\nthan zero order taylor coefficients!\n");
    exit (-1);
  }

  if (for_location_cnt > fax)
  { if (fax)
      free((char *) T0);
    T0 = myalloc1(for_location_cnt);
    fax = for_location_cnt;
  }




  if (keep)
  { taylbuf = 8388608/(keep*sizeof(double));
    taylbuf *= keep*sizeof(double);
    taylor_begin(taylbuf,&T0,keep-1);
  }
// 682 "uni5_for.cpp"
  init_for_sweep(tag);

  operation=*g_op_ptr++;
  while (operation !=35)
  {
   switch (operation){






      case 37:
        get_op_block_f();
        operation=*g_op_ptr++;

        break;


      case 38:
        get_loc_block_f();
        break;


      case 39:
        get_val_block_f();
        break;

      case 36:
      case 35:
 break;






      case 102:
        arg = *g_loc_ptr++;

        if (T0[arg] != 0)
   {

          if (keep){ fprintf((DIAG_OUT),"FATAL BETADIFF ERROR - consult a maintainer.\nSucceeding reverse sweep will fail! operation=%d, arg=%d, T0[arg]=%g\n",operation,arg,T0[arg]); taylor_close(-1,depcheck,indcheck);}
          end_sweep();
          return (-1);
        }
        ret_c = 0;
        break;


      case 103:
        arg = *g_loc_ptr++;

        if (T0[arg] == 0)
   {

          if (keep){ fprintf((DIAG_OUT),"FATAL BETADIFF ERROR - consult a maintainer.\nSucceeding reverse sweep will fail! operation=%d, arg=%d, T0[arg]=%g\n",operation,arg,T0[arg]); taylor_close(-1,depcheck,indcheck);}
          end_sweep();
          return (-1);
        }
        break;


      case 104:
        arg = *g_loc_ptr++;

        if (T0[arg] > 0)
   {

          if (keep){ fprintf((DIAG_OUT),"FATAL BETADIFF ERROR - consult a maintainer.\nSucceeding reverse sweep will fail! operation=%d, arg=%d, T0[arg]=%g\n",operation,arg,T0[arg]); taylor_close(-1,depcheck,indcheck);}
          end_sweep();
          return (-1);
        }
        if (T0[arg] == 0)
          ret_c = 0;
        break;


      case 105:
        arg = *g_loc_ptr++;

        if (T0[arg] <= 0)
   {

          if (keep){ fprintf((DIAG_OUT),"FATAL BETADIFF ERROR - consult a maintainer.\nSucceeding reverse sweep will fail! operation=%d, arg=%d, T0[arg]=%g\n",operation,arg,T0[arg]); taylor_close(-1,depcheck,indcheck);}
          end_sweep();
          return (-1);
        }
        break;


      case 106:
        arg = *g_loc_ptr++;

        if (T0[arg] < 0)
   {

          if (keep){ fprintf((DIAG_OUT),"FATAL BETADIFF ERROR - consult a maintainer.\nSucceeding reverse sweep will fail! operation=%d, arg=%d, T0[arg]=%g\n",operation,arg,T0[arg]); taylor_close(-1,depcheck,indcheck);}
          end_sweep();
          return (-1);
        }
        if (T0[arg] == 0)
          ret_c = 0;
        break;


      case 107:
        arg = *g_loc_ptr++;

        if (T0[arg] >= 0)
   {

          if (keep){ fprintf((DIAG_OUT),"FATAL BETADIFF ERROR - consult a maintainer.\nSucceeding reverse sweep will fail! operation=%d, arg=%d, T0[arg]=%g\n",operation,arg,T0[arg]); taylor_close(-1,depcheck,indcheck);}
          end_sweep();
          return (-1);
        }
        break;






      case 4:

        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;

        if (keep) write_scaylor(T0[res]);

        T0[res] = T0[arg];
 #if 0
 ASSIGN_T(Targ,T[arg])
        ASSIGN_T(Tres,T[res])

       
   TRES_INC = TARG_INC;

 #endif
 break;


      case 5:

        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

        if (keep) write_scaylor(T0[res]);

 T0[res] = coval;
 #if 0
        ASSIGN_T(Tres, T[res])

       
   TRES_INC = 0;

 #endif
 break;


      case 92:

        res = *g_loc_ptr++;

        if (keep) write_scaylor(T0[res]);

 T0[res] = 0.0;
 #if 0
        ASSIGN_T(Tres, T[res])

       
   TRES_INC = 0;

 #endif
 break;


      case 91:

        res = *g_loc_ptr++;

        if (keep) write_scaylor(T0[res]);

 T0[res] = 1.0;
 #if 0
        ASSIGN_T(Tres, T[res])

       
   TRES_INC = 0;

 #endif
 break;


      case 2:

        res = *g_loc_ptr++;

        if (keep) write_scaylor(T0[res]);

 T0[res] = basepoint[indexi];
 #if 0
 ASSIGN_T(Tres, T[res])

       
         
       TRES_INC = ARGUMENT(indexi,l,i);

 #endif
 ++indexi;
 break;


      case 3:

 res = *g_loc_ptr++;

        valuepoint[indexd] = T0[res];
 #if 0
 ASSIGN_T(Tres, T[res])

        if (taylors != 0 )
         
           
       TAYLORS(indexd,l,i) = TRES_INC;

 #endif
 indexd++;
 break;






      case 6:

        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

        if (keep) write_scaylor(T0[res]);

        T0[res] += coval;
 break;


      case 7:

        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;

        if (keep) write_scaylor(T0[res]);

        T0[res] += T0[arg];
 #if 0
        ASSIGN_T(Tres, T[res])
 ASSIGN_T(Targ, T[arg])

       
   TRES_INC += TARG_INC;

 #endif
 break;


      case 8:

        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

        if (keep) write_scaylor(T0[res]);

 T0[res] -= coval;
 break;


      case 9:

        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;

        if (keep) write_scaylor(T0[res]);

 T0[res] -= T0[arg];
 #if 0
 ASSIGN_T(Tres, T[res])
 ASSIGN_T(Targ, T[arg])

       
   TRES_INC -= TARG_INC;

 #endif
 break;


      case 10:

        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

        if (keep) write_scaylor(T0[res]);

 T0[res] *= coval;
 #if 0
 ASSIGN_T(Tres, T[res])

       
     TRES_INC *= coval;

 #endif
 break;


      case 11:

        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;

        if (keep) write_scaylor(T0[res]);

 #if 0
 ASSIGN_T(Tres, T[res])
 ASSIGN_T(Targ, T[arg])

       
       

       
  
   { TRES_FODEC = T0[res]*TARG_DEC + TRES*T0[arg];
 #if 0
            TresOP = Tres-i;
            TargOP = Targ;

            for (j=0;j<i;j++)
              *Tres += (*TresOP++) * (*TargOP--);
            Tres--;
 #endif
   }

 #endif
        T0[res] *= T0[arg];
 break;


      case 95:
        res = *g_loc_ptr++;

        if (keep) write_scaylor(T0[res]);

        T0[res]++;
 break;


      case 96:
        res = *g_loc_ptr++;

        if (keep) write_scaylor(T0[res]);

        T0[res]--;
 break;






      case 12:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;

        if (keep) write_scaylor(T0[res]);

        T0[res] = T0[arg1] + T0[arg2];
 #if 0
 ASSIGN_T(Tres, T[res])
 ASSIGN_T(Targ1, T[arg1])
 ASSIGN_T(Targ2, T[arg2])

       
   TRES_INC = TARG1_INC + TARG2_INC;

 #endif
 break;


      case 13:

        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

        if (keep) write_scaylor(T0[res]);

        T0[res] = T0[arg] + coval;
 #if 0
 ASSIGN_T(Tres, T[res])
 ASSIGN_T(Targ, T[arg])

       
   TRES_INC = TARG_INC;

 #endif
 break;


      case 14:

        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;

        if (keep) write_scaylor(T0[res]);

        T0[res] = T0[arg1] - T0[arg2];
 #if 0
        ASSIGN_T(Tres, T[res])
 ASSIGN_T(Targ1, T[arg1])
 ASSIGN_T(Targ2, T[arg2])

       
   TRES_INC = TARG1_INC - TARG2_INC;

 #endif
 break;


      case 15:

        arg =*g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

        if (keep) write_scaylor(T0[res]);

        T0[res] = coval - T0[arg];
 #if 0
        ASSIGN_T(Tres, T[res])
        ASSIGN_T(Targ, T[arg])

       
   TRES_INC = -TARG_INC;

 #endif
 break;


      case 16:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;

        if (keep) write_scaylor(T0[res]);

 #if 0
        ASSIGN_T(Tres, T[res])
        ASSIGN_T(Targ1, T[arg1])
        ASSIGN_T(Targ2, T[arg2])


       
       
       

       
         
   { TRES_FODEC = T0[arg1]*TARG2_DEC + TARG1_DEC*T0[arg2];
 #if 0
            Targ1OP = Targ1-i+1;
            Targ2OP = Targ2;

            for (j=0;j<i;j++)
              *Tres += (*Targ1OP++) * (*Targ2OP--);
            Tres--;
 #endif
          }

 #endif
        T0[res] = T0[arg1] * T0[arg2];
 break;


      case 17:

        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

        if (keep) write_scaylor(T0[res]);

        T0[res] = T0[arg] * coval;
 #if 0
        ASSIGN_T(Tres, T[res])
        ASSIGN_T(Targ, T[arg])

       
   TRES_INC = TARG_INC * coval;

 #endif
 break;


      case 18:

        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;

        if (keep) write_scaylor(T0[res]);

 #if 0
 divs = 1.0 / T0[arg2];
 #endif

        T0[res] = T0[arg1] / T0[arg2];
 #if 0
        ASSIGN_T(Tres, T[res])
        ASSIGN_T(Targ1, T[arg1])
        ASSIGN_T(Targ2, T[arg2])

       
         
   {
 #if 0
            zOP = z+i;
            (*zOP--) = -(*Targ2) * divs;
 #endif

            TRES_FOINC = TARG1_INC * divs + T0[res] * (-TARG2_INC * divs);

 #if 0
            TresOP = Tres-i;

     for (j=0;j<i;j++)
       *Tres += (*TresOP++) * (*zOP--);
            Tres++;
 #endif
   }

 #endif
 break;


      case 19:
        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

        if (keep) write_scaylor(T0[res]);


        if (arg == res)
        { if (keep) write_scaylor(T0[arg]);
 }

 #if 0
 divs = 1.0 / T0[arg];
 #endif

        T0[res] = coval / T0[arg];
 #if 0
        ASSIGN_T(Tres, T[res])
        ASSIGN_T(Targ, T[arg])

       
         
   {
 #if 0
            zOP = z+i;
            (*zOP--) = -(*Targ) * divs;
 #endif

            TRES_FOINC = T0[res] * (-TARG_INC * divs);

 #if 0
            TresOP = Tres-i;

     for (j=0;j<i;j++)
       *Tres += (*TresOP++) * (*zOP--);
            Tres++;
 #endif
   }

 #endif
 break;






      case 98:
        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;
        if (keep) write_scaylor(T0[res]);

        T0[res] = T0[arg];
 #if 0
 ASSIGN_T(Tres, T[res])
 ASSIGN_T(Targ, T[arg])

       
   TRES_INC = TARG_INC;

 #endif
 break;


      case 97:
        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;

        if (keep) write_scaylor(T0[res]);

        T0[res] = -T0[arg];
 #if 0
 ASSIGN_T(Tres, T[res])
 ASSIGN_T(Targ, T[arg])

       
   TRES_INC = -TARG_INC;

 #endif
 break;






      case 20:
        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;

        if (keep) write_scaylor(T0[res]);

        T0[res] = exp(T0[arg]);
 #if 0
 ASSIGN_T(Tres, T[res])
 ASSIGN_T(Targ, T[arg])

       
         
   {
 #if 0
            zOP = z+i;
     (*zOP--) = (i+1) * (*Targ);
 #endif

            TRES_FOINC = T0[res] * TARG_INC;

 #if 0
            TresOP = Tres-i;

            *Tres *= (i+1);
     for (j=0;j<i;j++)
       *Tres += (*TresOP++) * (*zOP--);
     *Tres++ /= (i+1);
 #endif
          }


 #endif
 break;


      case 22:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;

        if (keep) write_scaylor(T0[arg2]);
        if (keep) write_scaylor(T0[res]);

 T0[arg2] = cos(T0[arg1]);
 T0[res] = sin(T0[arg1]);
 #if 0
 ASSIGN_T(Tres, T[res])
 ASSIGN_T(Targ1, T[arg1])
        ASSIGN_T(Targ2, T[arg2])

       
         
   {
 #if 0
            zOP = z+i;
     (*zOP--) = (i+1) * (*Targ1);
 #endif

            TARG2_FOINC = -T0[res] * TARG1;
            TRES_FOINC = T0[arg2] * TARG1_INC;

 #if 0
            TresOP = Tres-i;
            Targ2OP = Targ2-i;

            *Tres *= (i+1);
            *Targ2 *= (i+1);
     for (j=0;j<i;j++)
     { *Tres += (*Targ2OP++) * (*zOP);
              *Targ2 -= (*TresOP++) * (*zOP--);
     }
     *Targ2++ /= (i+1);
     *Tres++ /= (i+1);
 #endif
   }

 #endif
 break;


      case 21:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;

        if (keep) write_scaylor(T0[arg2]);
        if (keep) write_scaylor(T0[res]);

        T0[arg2] = sin(T0[arg1]);
        T0[res] = cos(T0[arg1]);
 #if 0
 ASSIGN_T(Tres, T[res])
 ASSIGN_T(Targ1, T[arg1])
 ASSIGN_T(Targ2, T[arg2])

       
         
   {
 #if 0
            zOP = z+i;
     (*zOP--) = (i+1) * (*Targ1);
 #endif

            TARG2_FOINC = T0[res] * TARG1;
            TRES_FOINC = -T0[arg2] * TARG1_INC;

 #if 0
            TresOP = Tres-i;
            Targ2OP = Targ2-i;

            *Tres *= (i+1);
            *Targ2 *= (i+1);
     for (j=0;j<i;j++)
     { *Tres -= (*Targ2OP++) * (*zOP);
              *Targ2 += (*TresOP++) * (*zOP--);
     }
     *Targ2++ /= (i+1);
     *Tres++ /= (i+1);
 #endif
   }

 #endif
 break;


      case 23:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;

        if (keep) write_scaylor(T0[res]);

        T0[res]=atan(T0[arg1]);
 #if 0
        ASSIGN_T(Tres, T[res])
        ASSIGN_T(Targ1, T[arg1])
        ASSIGN_T(Targ2, T[arg2])

       
        {
   {
 #if 0
            zOP = z+i;
     (*zOP--) = (i+1) * (*Targ1);
 #endif

            TRES_FOINC = T0[arg2] * TARG1_INC;

 #if 0
            Targ2OP = Targ2;

            *Tres *= (i+1);
     for (j=0;j<i;j++)
       *Tres += (*Targ2OP++) * (*zOP--);
     *Tres++ /= (i+1);
 #endif
   }
         
        }

 #endif
 break;


      case 26:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;

        if (keep) write_scaylor(T0[res]);

        T0[res] = asin(T0[arg1]);
 #if 0
        ASSIGN_T(Tres, T[res])
        ASSIGN_T(Targ1, T[arg1])
        ASSIGN_T(Targ2, T[arg2])

        if (T0[arg1] == 1.0)
         
          {
              if (TARG1 > 0.0)
              { r0 = make_nan();
               
                ;
              }
              else
                if (TARG1 < 0.0)
                { r0 = make_inf();
                 
                  ;
                }
                else
                { r0 = 0.0;
                  Targ1++;
                }
            TRES = r0;
           
          }
        else
          if (T0[arg1] == -1.0)
           
            {
                if (TARG1 > 0.0)
                { r0 = make_inf();
                 
                  ;
                }
                else
                  if (TARG1 < 0.0)
                  { r0 = make_nan();
                   
                    ;
                  }
                  else
                  { r0 = 0.0;
                    Targ1++;
                  }
              TRES = r0;
             
            }
          else
           
            {
              {
 #if 0
                zOP = z+i;
                (*zOP--) = (i+1) * (*Targ1);
 #endif

                TRES_FOINC = T0[arg2] * TARG1_INC;

 #if 0
                Targ2OP = Targ2;

                *Tres *= (i+1);
           for (j=0;j<i;j++)
           *Tres += (*Targ2OP++) * (*zOP--);
         *Tres++ /= (i+1);
 #endif
       }
             
            }

 #endif
 break;


      case 27:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;

        if (keep) write_scaylor(T0[res]);

        T0[res] = acos(T0[arg1]);
 #if 0
        ASSIGN_T(Tres, T[res])
        ASSIGN_T(Targ1, T[arg1])
        ASSIGN_T(Targ2, T[arg2])

        if (T0[arg1] == 1.0)
         
          {
              if (TARG1 > 0.0)
              { r0 = make_nan();
               
                ;
              }
              else
                if (TARG1 < 0.0)
                { r0 = -make_inf();
                 
                  ;
                }
                else
                { r0 = 0.0;
                  Targ1++;
                }
            TRES = r0;
           
          }
        else
          if (T0[arg1] == -1.0)
           
            {
                if (TARG1 > 0.0)
                { r0 = -make_inf();
                 
                  ;
                }
                else
                  if (TARG1 < 0.0)
                  { r0 = make_nan();
                   
                    ;
                  }
                  else
                  { r0 = 0.0;
                    Targ1++;
                  }
              TRES = r0;
             
            }
          else
           
            {
       {
 #if 0
                zOP = z+i;
                (*zOP--) = (i+1) * (*Targ1);
 #endif

                TRES_FOINC = T0[arg2] * TARG1_INC;

 #if 0
                Targ2OP = Targ2;

                *Tres *= (i+1);
           for (j=0;j<i;j++)
           *Tres += (*Targ2OP++) * (*zOP--);
         *Tres++ /= (i+1);
 #endif
       }
             
            }

 #endif
 break;
// 1880 "uni5_for.cpp"
      case 24:
        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;

        if (keep) write_scaylor(T0[res]);

 #if 0
 ASSIGN_T(Tres, T[res])
 ASSIGN_T(Targ, T[arg])

        divs = 1.0 / T0[arg];
       
        { if (T0[arg] == 0.0)
          { TargOP = Targ;
           
            { if (*TargOP++ < 0.0)
              { divs = make_nan();
                ;
              }
     }
          }


         
   { TRES_FOINC = TARG_INC * divs;
 #if 0
            TresOP = Tres - i;
            zOP = z+i;

            (*zOP--) = *Tres;
     (*Tres) *= i+1;
      for (j=0;j<i;j++)
       (*Tres) -= (*zOP--) * (*TresOP++) * (j+1);
     *Tres++ /= i+1;
 #endif
          }
        }

 #endif
        T0[res] = log(T0[arg]);
 break;


      case 25:
        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

        if (keep) write_scaylor(T0[res]);


        if (arg == res)
        { if (keep) write_scaylor(T0[arg]);
 }

 #if 0
        T0temp = T0[arg];
 #endif

        T0[res] = pow(T0[arg], coval);
 #if 0
 ASSIGN_T(Tres, T[res])
 ASSIGN_T(Targ, T[arg])

        if (T0temp == 0.0)
         
          {
            { if (TARG > 0.0)
              { if (coval <= 0.0)
           r0 = make_nan();
                else
                  if (coval > 1.0)
                    r0 = 0.0;
                  else
                    if (coval == 1.0)
               r0 = 1.0 ;
                    else
               r0 = make_inf();
               
                ;
              }
              else
                if (TARG < 0.0)
                { r0 = make_nan();
                 
                  ;
                }
                else
                { r0 = 0.0;
                  Targ++;
         }
            }
     TRES_INC = r0;
 #if 0
            for (i=1;i<k;i++)
            { *Tres++ = make_nan();
     }
 #endif
          }
        else
   { r0 = 1.0 / T0temp;
         
           
            {
 #if 0
              zOP = z+i;
              (*zOP--) = (*Targ) * r0;
 #endif

              TRES_FOINC = T0[res] * TARG_INC * coval * r0;

 #if 0
              TresOP = Tres-i;

        (*Tres) *= i+1;
       y = coval*i -1;
              for (j=0;j<i;j++)
              { *Tres += (*TresOP++) * (*zOP--) * y;
  y -= coval + 1;
       }
       *Tres++ /= (i+1);
 #endif
     }
        }

 #endif
 break;


      case 28:
        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;

        if (keep) write_scaylor(T0[res]);

        T0[res] = sqrt(T0[arg]);
 #if 0
        ASSIGN_T(Targ, T[arg])
 ASSIGN_T(Tres, T[res])

       
        { TargOP = Targ;
          if (T0[arg] == 0.0)
          { r0 = 0.0;
           
     { if (TARG>0.0)
              { r0 = make_inf();
               
                ;
              }
              else
               if (TARG<0.0)
               { r0 = make_nan();
                
                 ;
               }
               else
                 Targ++;
            }
          }
          else
          { r0 = 0.5/T0[res];
          }
          Targ = TargOP;

   even = 1;
         
   { TRES_FOINC = r0 * TARG_INC;
 #if 0
            TresOP = Tres-i;
            TresOP2 = Tres-1;

            x = 0;
            for (j=1;2*j-1<i;j++)
              x += (*TresOP++) * (*TresOP2--);
     x *= 2;
     if (!even)
              x += (*TresOP) * (*TresOP2);
     even = !even;
     *Tres++ -= r0*x;
 #endif
   }
        }

 #endif
 break;


      case 32:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;

        if (*g_real_ptr++!=T0[arg1])
   {

          if (keep){ fprintf((DIAG_OUT),"FATAL BETADIFF ERROR - consult a maintainer.\nSucceeding reverse sweep will fail! operation=%d, arg=%d, T0[arg]=%g\n",operation,arg,T0[arg]); taylor_close(-1,depcheck,indcheck);}
          end_sweep();
          return -2;
        }
        coval = *g_real_ptr++;

        if (keep) write_scaylor(T0[res]);

        T0[res] = coval;
 #if 0
        ASSIGN_T(Tres, T[res])
        ASSIGN_T(Targ1, T[arg1])
        ASSIGN_T(Targ2, T[arg2])

       
        {
   {
 #if 0
            zOP = z+i;
     (*zOP--) = (i+1) * (*Targ1);
 #endif

            TRES_FOINC = T0[arg2] * TARG1_INC;

 #if 0
            Targ2OP = Targ2;

            *Tres *= (i+1);
     for (j=0;j<i;j++)
       *Tres += (*Targ2OP++) * (*zOP--);
     *Tres++ /= (i+1);
 #endif
   }
         
        }

 #endif
 break;


      case 100:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

        if (keep) write_scaylor(T0[res]);




        if (T0[arg1] > T0[arg2])
        { if (coval)
            if ((ret_c) > (2)) (ret_c) = (2);
        }
        else
          if (T0[arg1] < T0[arg2])
          { if (!coval)
              if ((ret_c) > (2)) (ret_c) = (2);
          }
          else
            if (arg1 != arg2)
              if ((ret_c) > (1)) (ret_c) = (1);

 #if 0
        ASSIGN_T(Targ1, T[arg1])
        ASSIGN_T(Targ2, T[arg2])
        ASSIGN_T(Tres, T[res])

        Tqo = __null;
        if (T0[arg1] > T0[arg2])
          Tqo = Targ2;
        else
          if (T0[arg1] < T0[arg2])
            Tqo = Targ1;

       
        { Targ = Tqo;
          if (Targ == __null)
          { Targ1OP = Targ1;
            Targ2OP = Targ2;
           
            { if (TARG1 > TARG2)
              { Targ = Targ2OP;
               
               
                ;
              }
              else
                if (TARG1 < TARG2)
                { Targ = Targ1OP;
                 
                 
                  ;
                }
              Targ1++; Targ2++;
            }
            if (Targ == __null)
              Targ = Targ1OP;
   }

         
            TRES_INC = TARG_INC;

          if (Tqo)
          {
   }
        }

 #endif
        T0[res] = ((T0[arg2]<T0[arg1])?T0[arg2]:T0[arg1]);
        break;


      case 101:
        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

        if (keep) write_scaylor(T0[res]);




        if (T0[arg] < 0.0)
        { if (coval)
            if ((ret_c) > (2)) (ret_c) = (2);
        }
        else
          if (T0[arg] > 0.0)
          { if (!coval)
              if ((ret_c) > (2)) (ret_c) = (2);
          }

 #if 0
        ASSIGN_T(Tres, T[res])
        ASSIGN_T(Targ, T[arg])

        y = 0.0;
        if (T0[arg] != 0.0)
          if (T0[arg] < 0.0)
            y = -1.0;
          else
            y = 1.0;

       
        { x = y;
         
          { if ((x == 0.0) && (TARG != 0.0))
            { if ((ret_c) > (1)) (ret_c) = (1);
              if (TARG < 0.0)
                x = -1.0;
              else
                x = 1.0;
            }
            TRES_INC = x * TARG_INC;
          }
        }

 #endif
        T0[res] = fabs(T0[arg]);
        break;


      case 115:
        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

        if (keep) write_scaylor(T0[res]);

        T0[res]=ceil(T0[arg]);

        if (coval != T0[res])
          if ((ret_c) > (2)) (ret_c) = (2);
 #if 0
        ASSIGN_T(Tres, T[res])

       
          TRES_INC = 0.0;

 #endif
        break;


      case 116:
        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

        if (keep) write_scaylor(T0[res]);

        T0[res] = floor(T0[arg]);

        if (coval != T0[res])
          if ((ret_c) > (2)) (ret_c) = (2);
 #if 0
        ASSIGN_T(Tres, T[res])

       
          TRES_INC = 0.0;

 #endif
        break;






      case 70:
        arg = *g_loc_ptr++;
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

        if (keep) write_scaylor(T0[res]);


 #if 0
        ASSIGN_T(Tres, T[res])
        ASSIGN_T(Targ1, T[arg1])
        ASSIGN_T(Targ2, T[arg2])

        if (T0[arg] > 0)
         
            TRES_INC = TARG1_INC;
        else
         
            TRES_INC = TARG2_INC;
 #endif

        if (T0[arg] > 0)
        { if (coval <= 0.0)
            if ((ret_c) > (2)) (ret_c) = (2);
          T0[res] = T0[arg1];
        }
        else
        { if (coval > 0.0)
            if ((ret_c) > (2)) (ret_c) = (2);
          if (T0[arg] == 0)
            if ((ret_c) > (0)) (ret_c) = (0);
          T0[res] = T0[arg2];
        }
        break;


      case 71:
        arg = *g_loc_ptr++;
        arg1 = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

        if (keep) write_scaylor(T0[res]);


 #if 0
        ASSIGN_T(Tres, T[res])
        ASSIGN_T(Targ1, T[arg1])

        if (T0[arg] > 0)
         
            TRES_INC = TARG1_INC;
 #endif

        if (T0[arg] > 0)
 { if (coval <= 0.0)
            if ((ret_c) > (2)) (ret_c) = (2);
          T0[res] = T0[arg1];
        }
        else
          if (T0[arg] == 0)
            if ((ret_c) > (0)) (ret_c) = (0);
        break;






      case 52:
        arg = *g_loc_ptr++;
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;

        for (ls=0; ls<size; ls++)
        {
          if (keep) write_scaylor(T0[res]);
          T0[res] = T0[arg];
 #if 0
          ASSIGN_T(Targ, T[arg])
          ASSIGN_T(Tres, T[res])

         
     TRES_INC = TARG_INC;

 #endif
          res++; arg++;
       }
        break;


      case 53:
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;
        d = get_val_v_f(size);

        for (ls=0; ls<size; ls++)
        {
          if (keep) write_scaylor(T0[res]);

          T0[res] = *d++;
 #if 0
          ASSIGN_T(Tres, T[res])

         
     TRES_INC = 0;

 #endif
          res++;
        }
        break;


      case 54:
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;

        for (ls=0; ls<size; ls++)
        {
          if (keep) write_scaylor(T0[res]);

          T0[res] = basepoint[indexi];
 #if 0
          ASSIGN_T(Tres, T[res])

         
           
              TRES_INC = ARGUMENT(indexi,l,i);

 #endif
          ++indexi;
          res++;
        }
        break;


      case 55:
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;

        for (ls=0; ls<size; ls++)
        {

          valuepoint[indexd] = T0[res];
 #if 0
          ASSIGN_T(Tres, T[res])

          if (taylors != 0 )
           
             
         TAYLORS(indexd,l,i) = TRES_INC;

 #endif
          indexd++;
          res++;
        }
        break;






      case 59:
        arg = *g_loc_ptr++;
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;
        for (ls=0; ls<size; ls++)
        {
          if (keep) write_scaylor(T0[res]);
   T0[res] += T0[arg];
 #if 0
          ASSIGN_T(Tres, T[res])
          ASSIGN_T(Targ, T[arg])

         
     TRES_INC += TARG_INC;

 #endif
          res++; arg++;
        }
        break;


      case 57:
        arg = *g_loc_ptr++;
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;

        for (ls=0; ls<size; ls++)
        {
          if (keep) write_scaylor(T0[res]);

          T0[res] -= T0[arg];
 #if 0
          ASSIGN_T(Tres, T[res])
          ASSIGN_T(Targ, T[arg])

         
     TRES_INC -= TARG_INC;

 #endif
          res++; arg++;
        }
        break;


      case 61:
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

        for (ls=0; ls<size; ls++)
        {
          if (keep) write_scaylor(T0[res]);

          T0[res] *= coval;
 #if 0
          ASSIGN_T(Tres, T[res])

         
       TRES_INC *= coval;

 #endif
          res++;
        }
        break;


      case 62:
        arg = *g_loc_ptr++;
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;



        checkSize = res+size;

        for (ls=0; ls<size; ls++)
        { if (res == arg)
            res++;
          if (res == checkSize)
            res = arg;


          if (keep) write_scaylor(T0[res]);

 #if 0
          ASSIGN_T(Tres, T[res])
          ASSIGN_T(Targ, T[arg])

         
         

         
    
     { TRES_FODEC = T0[res]*TARG_DEC + TRES*T0[arg];
 #if 0
              TresOP = Tres-i;
              TargOP = Targ;

              for (j=0;j<i;j++)
                *Tres += (*TresOP++) * (*TargOP--);
              Tres--;
 #endif
     }

 #endif
          T0[res] *= T0[arg];
          res++;
        }
       break;






      case 40:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;

        for (ls=0; ls<size; ls++)
        {
          if (keep) write_scaylor(T0[res]);

          T0[res] = T0[arg1] + T0[arg2];
 #if 0
          ASSIGN_T(Tres, T[res])
          ASSIGN_T(Targ1, T[arg1])
          ASSIGN_T(Targ2, T[arg2])

         
     TRES_INC = TARG1_INC + TARG2_INC;

 #endif
          res++; arg1++; arg2++;
        }
        break;


      case 42:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;

        for (ls=0; ls<size; ls++)
        {
          if (keep) write_scaylor(T0[res]);

          T0[res] = T0[arg1] - T0[arg2];
 #if 0
          ASSIGN_T(Tres, T[res])
          ASSIGN_T(Targ1, T[arg1])
          ASSIGN_T(Targ2, T[arg2])

         
     TRES_INC = TARG1_INC - TARG2_INC;

 #endif
          res++; arg1++; arg2++;
        }
        break;


      case 45:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;

        if (keep) write_scaylor(T0[res]);

 T0temp = 0.0;


 #if 0
        if ( ((res >= arg1) && (res < arg1+size))
            || ((res >= arg2) && (res < arg2+size)) )
 { ASSIGN_T(TresOP, Ttemp)
          flag = 1;
 }
        else
        { ASSIGN_T(TresOP, T[res])
          flag = 0;
 }

        Tres = TresOP;
       
          TRES_INC = 0.0;
 #endif

        for (ls=0; ls<size; ls++)
        {
 #if 0
          Tres = TresOP;
          ASSIGN_T(Targ1, T[arg1])
          ASSIGN_T(Targ2, T[arg2])


         
         
         

         
           
     { TRES_FODEC += T0[arg1]*TARG2_DEC + TARG1_DEC*T0[arg2];
 #if 0
              Targ1OP = Targ1-i+1;
              Targ2OP = Targ2;

              for (j=0;j<i;j++)
                *Tres += (*Targ1OP++) * (*Targ2OP--);
              Tres--;
 #endif
            }
 #endif
          T0temp += T0[arg1] * T0[arg2];
          arg1++; arg2++;
        }


        T0[res] = T0temp;
 #if 0
        if (flag)
 { ASSIGN_T(Tres,T[res])
          Tqo = TresOP;

         
            TRES_INC = TQO_INC;
 }
 #endif
 break;


      case 47:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;



        checkSize = res+size;

        for (ls=0; ls<size; ls++)
        { if (res == arg2)
          { res++; arg1++;
   }
          if (res == checkSize)
          { arg1 -= res-arg2;
            res = arg2;
   }


          if (keep) write_scaylor(T0[res]);

 #if 0
          ASSIGN_T(Tres, T[res])
          ASSIGN_T(Targ1, T[arg1])
          ASSIGN_T(Targ2, T[arg2])


         
         
         

         
           
     { TRES_FODEC = T0[arg1]*TARG2_DEC + TARG1_DEC*T0[arg2];
 #if 0
              Targ1OP = Targ1-i+1;
              Targ2OP = Targ2;

              for (j=0;j<i;j++)
                *Tres += (*Targ1OP++) * (*Targ2OP--);
              Tres--;
 #endif
            }

 #endif
          T0[res] = T0[arg1] * T0[arg2];
          res++; arg1++;
        }
        break;


      case 48:
        arg = *g_loc_ptr++;
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

        for (ls=0; ls<size; ls++)
        {
          if (keep) write_scaylor(T0[res]);

          T0[res] = T0[arg] * coval;
 #if 0
          ASSIGN_T(Tres, T[res])
          ASSIGN_T(Targ, T[arg])

         
     TRES_INC = TARG_INC * coval;

 #endif
          res++; arg++;
        }
        break;


      case 60:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;

 #if 0
        divs = 1.0 / T0[arg2];
 #endif



        checkSize = res+size;

        for (ls=0; ls<size; ls++)
        { if (res == arg2)
          { res++; arg1++;
   }
          if (res == checkSize)
          { arg1 -= res-arg2;
            res = arg2;
   }


          if (keep) write_scaylor(T0[res]);

          T0[res] = T0[arg1] / T0[arg2];
 #if 0
          ASSIGN_T(Tres, T[res])
          ASSIGN_T(Targ1, T[arg1])
          ASSIGN_T(Targ2, T[arg2])

         
           
     {
 #if 0
              zOP = z+i;
              (*zOP--) = -(*Targ2) * divs;
 #endif


              TRES_FOINC = TARG1_INC * divs + T0[res] * (-TARG2_INC * divs);

 #if 0
              TresOP = Tres-i;

       for (j=0;j<i;j++)
         *Tres += (*TresOP++) * (*zOP--);
              Tres++;
 #endif
     }

 #endif
          res++; arg1++;
        }
        break;






      case 75:
        arg2 = *g_loc_ptr++;
        arg1 = *g_loc_ptr++;
        res = *g_loc_ptr++;

        arg = arg2 + (int)(T0[arg1]);

        if ( (int)(T0[arg1]) != (int)(*g_real_ptr++) )
          if ((ret_c) > (2)) (ret_c) = (2);


        if (keep) write_scaylor(T0[res]);

        T0[res] = T0[arg];
 #if 0
        ASSIGN_T(Tres, T[res])
        ASSIGN_T(Targ, T[arg])

       
          TRES_INC = TARG_INC;

 #endif
        break;


      case 76:
        arg2 = *g_loc_ptr++;
 arg1 = *g_loc_ptr++;
        arg = *g_loc_ptr++;

        res = arg2 + (int)(T0[arg1]);

        if ( (int)(T0[arg1]) != (int)(*g_real_ptr++) )
          if ((ret_c) > (2)) (ret_c) = (2);

        if (keep) write_scaylor(T0[res]);

        T0[res] = T0[arg];
 #if 0
        ASSIGN_T(Tres, T[res])
        ASSIGN_T(Targ, T[arg])

       
          TRES_INC = TARG_INC;

 #endif
        break;


      case 77:
        arg2 = *g_loc_ptr++;
        arg1 = *g_loc_ptr++;

        arg = arg2+(int)(T0[arg1]);

        if (keep) write_scaylor(T0[arg]);

        T0[arg] = *g_real_ptr++;

        if ( (int)(T0[arg1]) != (int)(*g_real_ptr++) )
          if ((ret_c) > (2)) (ret_c) = (2);
 #if 0
        ASSIGN_T(Targ, T[arg])

       
          TARG_INC = 0;

 #endif
        break;


      case 72:
 fprintf((stderr),"doing m_subscript\n"); exit(12);
        arg2 = *g_loc_ptr++;
        arg1 = *g_loc_ptr++;
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;

        if ( (int)(T0[arg1]) != (int)(*g_real_ptr++) )
          if ((ret_c) > (2)) (ret_c) = (2);

        arg = arg2 + (int)(T0[arg1])*size;

 if (T0[arg1] != (int)T0[arg1]){
   fprintf((stderr),"T0[arg1] is not an integer in m_subscript in uni5_for.c\n"); exit(12);}

        for (ls=0; ls<size; ls++)
        {
          if (keep) write_scaylor(T0[res]);

          T0[res] = T0[arg];
 #if 0
          ASSIGN_T(Tres, T[res])
          ASSIGN_T(Targ, T[arg])

         
            TRES_INC = TARG_INC;

 #endif
         res++; arg++;
        }
        break;


      case 73:
 fprintf((stderr),"doing m_subscript_l\n"); exit(12);
        arg2 = *g_loc_ptr++;
 arg1 = *g_loc_ptr++;
        size = *g_loc_ptr++;
        arg = *g_loc_ptr++;

        if ( (int)(T0[arg1]) != (int)(*g_real_ptr++) )
          if ((ret_c) > (2)) (ret_c) = (2);

        res = arg2 + (int)(T0[arg1])*size;
        for (ls=0; ls<size; ls++)
        { if (keep) write_scaylor(T0[res]);

          T0[res] = T0[arg];
 #if 0
          ASSIGN_T(Tres, T[res])
          ASSIGN_T(Targ, T[arg])

         
            TRES_INC = TARG_INC;

 #endif
          res++; arg++;
        }
        break;


      case 74:
 fprintf((stderr),"doing m_subscript_ld\n"); exit(12);
        arg2 = *g_loc_ptr++;
        arg1 = *g_loc_ptr++;
        arg = *g_loc_ptr++;
        size = *g_loc_ptr++;

        if ( (int)(T0[arg1]) != (int)(*g_real_ptr++) )
          if ((ret_c) > (2)) (ret_c) = (2);

        d = get_val_v_f(size);

        res = arg2 + (int)(T0[arg1])*size + arg;
        for (ls=0; ls<size; ls++)
        { if (keep) write_scaylor(T0[res]);

          T0[res] = d[ls];
 #if 0
          ASSIGN_T(Tres, T[res])

         
            TRES_INC = 0.0;

 #endif
          res++;
        }
        break;






      case 90:
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;
        d = get_val_v_f(size);

        for (ls=0;ls<size;ls++)
        { T0[res]=*d;
 #if 0
          ASSIGN_T(Tres,T[res])

         
            TRES_INC = 0;

 #endif
          res++; d++;
        }
        break;


      case 1:
        arg1=*g_loc_ptr++;
        arg2=*g_loc_ptr++;


        if (keep)
        { do
            if (keep) write_scaylor(T0[arg2]);
          while(arg1 < arg2-- );
        }

   break;


      default:


        fprintf((DIAG_OUT),"ADOL-C fatal error in " "zos_forward" " ("
                       "uni5_for.cpp"
                       ") : no such operation %d\n", operation);
 exit(12);
 break;

      }


      operation=*g_op_ptr++;
    }



  if (keep) taylor_close(taylbuf,depcheck,indcheck);



  end_sweep();
  return ret_c;
}






