ifeq ($(MINGW),TRUE) # MS-Windows MINGW compilation
  MINGW_OPTIONS=-Lc:/MinGw/lib -lgw32c -lwsock32 -lc
else
  MINGW_OPTIONS=
endif

CXX = $(COMPILER)
CXXFLAGS = $(FAST) -Dbool_LIB -Wall

DIFF = ./sdiff
PRE = ./
MAJOR = 1
MINOR = 0

%.o:           	%.cpp
		$(CXX) $(CXXFLAGS) -c $*.cpp

everything:    	tryrand

tryrand_obj = tryrand.o newran.o myexcept.o extreal.o tryrand1.o tryrand2.o tryrand3.o tryrand4.o tryrand5.o hist.o

tryrand:       	$(tryrand_obj)
		$(CXX) -o $@ $(tryrand_obj) -L. -lm

tryrand.o:     	tryrand.cpp include.h newran.h tryrand.h boolean.h myexcept.h extreal.h

newran.o:      	newran.cpp include.h newran.h boolean.h myexcept.h extreal.h

myexcept.o:    	myexcept.cpp include.h boolean.h myexcept.h

extreal.o:     	extreal.cpp include.h boolean.h extreal.h

tryrand1.o:    	tryrand1.cpp include.h newran.h tryrand.h boolean.h myexcept.h extreal.h

tryrand2.o:    	tryrand2.cpp include.h newran.h tryrand.h boolean.h myexcept.h extreal.h

tryrand3.o:    	tryrand3.cpp include.h newran.h tryrand.h boolean.h myexcept.h extreal.h

tryrand4.o:    	tryrand4.cpp include.h newran.h tryrand.h boolean.h myexcept.h extreal.h

tryrand5.o:    	tryrand5.cpp include.h newran.h tryrand.h boolean.h myexcept.h extreal.h

hist.o:        	hist.cpp include.h boolean.h extreal.h newran.h tryrand.h myexcept.h

tryrand.txx:   	tryrand
		$(PRE)tryrand > tryrand.txx
		$(DIFF) tryrand.txt tryrand.txx

clean:
	rm -f *.o; \
	rm -f tryrand \
	rm -f tryrand.exe
	rm -f *.o
	rm -f *.a


