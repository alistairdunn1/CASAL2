#'@export
"casal2.binary.version"<-
function() {
return("24.11")
}
