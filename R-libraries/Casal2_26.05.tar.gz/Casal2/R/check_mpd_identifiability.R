#' @title check_mpd_identifiability
#'
#' @description
#' Do an eigen decomposition of the hessian matrix to identify correlated estimated parameters
#' and parameters with high uncertainty. Small or zero eigenvalues (high condition number)
#' indicates ill-posedness, i.e. the parameter estimation problem does not have a unique solution.
#' This eigenvalue decomposition has been widely used in the estimation literature
#'
#' @author Casal2 Development Team
#' @param cas2_mod Model object that are generated from the extract.mpd() function. It expects the report of type covariance_matrix to be present.
#' @param delta delta value
#' @return a data frame or message about the model
#' @rdname check_mpd_identifiability
#' @export check_mpd_identifiability

check_mpd_identifiability <- function(cas2_mod, delta = .Machine$double.eps) {
  # check that there is covariance and estimate_value report in this output
  report_types <- vapply(cas2_mod, function(x) if (is.null(x$type)) "" else x$type, character(1L))
  covar_ndx    <- match("covariance_matrix", report_types, nomatch = 0L)
  est_ndx      <- match("estimate_value",    report_types, nomatch = 0L)
  if (covar_ndx == 0) {
    stop("A report of type 'covariance_matrix' was not found. Please re-run the estimation with a @report with 'type covariance_matrix'")
  }
  if (est_ndx == 0) {
    stop("A report of type 'estimate_value' was not found. Please re-run the estimation with a @report with 'type estimate_value")
  }
  ## check covariance is invertable
  if (!isSymmetric(cas2_mod[[covar_ndx]]$covariance_matrix)) {
    stop("Error: the covariance matrix is not symmetric.")
  }
  ## check positive semi defintie matrix
  if (class(try(solve(cas2_mod[[covar_ndx]]$covariance_matrix), silent = T)) != "matrix") {
    stop("Error: the covariance matrix is not invertible (i.e., not positive definite)")
  }
  ## calculate hessian
  hess <- solve(cas2_mod[[covar_ndx]]$covariance_matrix)
  ## eigen decomposition
  Eig <- eigen(hess)
  WhichBad <- which(Eig$values < sqrt(delta))
  df <- NULL
  if (length(WhichBad) == 0) {
    if (est_ndx != 0) {
      params <- cas2_mod[[est_ndx]]$values
      df <- data.frame(Param = names(params), MPD = as.numeric(params), Param_check = "OK")
    } else {
      df <- data.frame(Paramupdate. = 1:ncol(hess), MPD = NA, Param_check = "OK")
    }
  } else {
    # for values with zero eigenvalues find the absolute largest eigenvector value
    RowMax <- apply(Eig$vectors[, WhichBad, drop = FALSE], MARGIN = 1, FUN = function(vec) {
      max(abs(vec))
    })
    if (est_ndx != 0) {
      params <- cas2_mod[[est_ndx]]$`1`$values
      df <- data.frame(Param = names(params), MPD = as.numeric(params), Param_check = ifelse(RowMax > 0.1, "Bad", "OK"))
    } else {
      df <- data.frame(Paramupdate. = 1:ncol(hess), MPD = NA, Param_check = ifelse(RowMax > 0.1, "Bad", "OK"))
    }
  }
  return(df)
}
