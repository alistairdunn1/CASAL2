#'@export
"casal2.binary.version"<-
function() {
return("23.12")
}
